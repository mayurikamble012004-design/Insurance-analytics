DESCRIBE opportunity;
DESCRIBE invoice;
DESCRIBE fees;
DESCRIBE brokerage;
DESCRIBE `individual budgets`;

##1.Create Combined Revenue Subquery

SELECT 
    `Account Exe ID`,
    revenue_transaction_type,
    Amount
FROM invoice

UNION ALL

SELECT 
    `Account Exe ID`,
    revenue_transaction_type,
    Amount
FROM fees

UNION ALL

SELECT 
    `Account Exe ID`,
    revenue_transaction_type,
    Amount
FROM brokerage;

##2.Now Aggregate Revenue Type Wise

SELECT 
    `Account Exe ID`,

    SUM(CASE 
        WHEN revenue_transaction_type = 'New' 
        THEN Amount ELSE 0 END) AS New_Achieved,

    SUM(CASE 
        WHEN revenue_transaction_type = 'Cross Sell' 
        THEN Amount ELSE 0 END) AS Cross_Achieved,

    SUM(CASE 
        WHEN revenue_transaction_type = 'Renewal' 
        THEN Amount ELSE 0 END) AS Renewal_Achieved

FROM (
    SELECT `Account Exe ID`, revenue_transaction_type, Amount FROM invoice
    UNION ALL
    SELECT `Account Exe ID`, revenue_transaction_type, Amount FROM fees
    UNION ALL
    SELECT `Account Exe ID`, revenue_transaction_type, Amount FROM brokerage
) AS combined_revenue

GROUP BY `Account Exe ID`;

##3.Join with Budget (Final Dataset)
SELECT 
    ib.Branch,
    ib.`Account Exe ID`,
    ib.`Employee Name`,

    ib.`New Budget`,
    ib.`Cross sell bugdet`,
    ib.`Renewal Budget`,

    COALESCE(r.New_Achieved,0) AS New_Achieved,
    COALESCE(r.Cross_Achieved,0) AS Cross_Achieved,
    COALESCE(r.Renewal_Achieved,0) AS Renewal_Achieved

FROM `individual budgets` ib

LEFT JOIN (

    SELECT 
        `Account Exe ID`,

        SUM(CASE WHEN revenue_transaction_type = 'New' 
                 THEN Amount ELSE 0 END) AS New_Achieved,

        SUM(CASE WHEN revenue_transaction_type = 'Cross Sell' 
                 THEN Amount ELSE 0 END) AS Cross_Achieved,

        SUM(CASE WHEN revenue_transaction_type = 'Renewal' 
                 THEN Amount ELSE 0 END) AS Renewal_Achieved

    FROM (
        SELECT `Account Exe ID`, revenue_transaction_type, Amount FROM invoice
        UNION ALL
        SELECT `Account Exe ID`, revenue_transaction_type, Amount FROM fees
        UNION ALL
        SELECT `Account Exe ID`, revenue_transaction_type, Amount FROM brokerage
    ) AS combined_revenue

    GROUP BY `Account Exe ID`

) r

ON ib.`Account Exe ID` = r.`Account Exe ID`

WHERE ib.Branch = 'Ahmedabad';

SELECT COUNT(*) FROM invoice;
SELECT COUNT(*) FROM fees;
SELECT COUNT(*) FROM brokerage;

SELECT DISTINCT revenue_transaction_type FROM invoice;
SELECT DISTINCT revenue_transaction_type FROM fees;
SELECT DISTINCT revenue_transaction_type FROM brokerage;

SELECT DISTINCT income_class 
FROM invoice;
SELECT DISTINCT income_class 
FROM fees;
SELECT DISTINCT income_class 
FROM brokerage;

##CASE income_class
SELECT 
    ib.Branch,
    ib.`Account Exe ID`,
    ib.`Employee Name`,

    ib.`New Budget`,
    ib.`Cross sell bugdet`,
    ib.`Renewal Budget`,

    COALESCE(r.New_Achieved,0) AS New_Achieved,
    COALESCE(r.Cross_Achieved,0) AS Cross_Achieved,
    COALESCE(r.Renewal_Achieved,0) AS Renewal_Achieved

FROM `individual budgets` ib

LEFT JOIN (

    SELECT 
        `Account Exe ID`,

        SUM(CASE 
            WHEN income_class = 'New' 
            THEN Amount ELSE 0 END) AS New_Achieved,

        SUM(CASE 
            WHEN income_class = 'Cross Sell' 
            THEN Amount ELSE 0 END) AS Cross_Achieved,

        SUM(CASE 
            WHEN income_class = 'Renewal' 
            THEN Amount ELSE 0 END) AS Renewal_Achieved

    FROM (
        SELECT `Account Exe ID`, income_class, Amount FROM invoice
        UNION ALL
        SELECT `Account Exe ID`, income_class, Amount FROM fees
        UNION ALL
        SELECT `Account Exe ID`, income_class, Amount FROM brokerage
    ) AS combined_revenue

    GROUP BY `Account Exe ID`

) r

ON ib.`Account Exe ID` = r.`Account Exe ID`

WHERE ib.Branch = 'Ahmedabad';

SELECT 
    `Account Exe ID`,
    
    ROUND(SUM(CASE 
        WHEN income_class = 'New' 
        THEN Amount ELSE 0 END),2) AS New_Achieved

FROM invoice
GROUP BY `Account Exe ID`;

SELECT 
    `Account Exe ID`,

    ROUND(SUM(CASE 
        WHEN income_class = 'New' 
        THEN Amount ELSE 0 END),2) AS New_Achieved,

    ROUND(SUM(CASE 
        WHEN income_class = 'Cross Sell' 
        THEN Amount ELSE 0 END),2) AS Cross_Achieved,

    ROUND(SUM(CASE 
        WHEN income_class = 'Renewal' 
        THEN Amount ELSE 0 END),2) AS Renewal_Achieved

CREATE VIEW final_kpi_ahmedabad AS

SELECT 
    ib.Branch,
    ib.`Account Exe ID`,
    ib.`Employee Name`,
    ib.`New Budget`,
    ib.`Cross sell bugdet`,
    ib.`Renewal Budget`,

    COALESCE(r.New_Achieved,0) AS New_Achieved,
    COALESCE(r.Cross_Achieved,0) AS Cross_Achieved,
    COALESCE(r.Renewal_Achieved,0) AS Renewal_Achieved

FROM `individual budgets` ib

LEFT JOIN (

    SELECT 
        `Account Exe ID`,

        ROUND(SUM(CASE 
            WHEN income_class = 'New' 
            THEN Amount ELSE 0 END),2) AS New_Achieved,

        ROUND(SUM(CASE 
            WHEN income_class = 'Cross Sell' 
            THEN Amount ELSE 0 END),2) AS Cross_Achieved,

        ROUND(SUM(CASE 
            WHEN income_class = 'Renewal' 
            THEN Amount ELSE 0 END),2) AS Renewal_Achieved

    FROM (
        SELECT `Account Exe ID`, income_class, Amount FROM invoice
        UNION ALL
        SELECT `Account Exe ID`, income_class, Amount FROM fees
        UNION ALL
        SELECT `Account Exe ID`, income_class, Amount FROM brokerage
    ) AS combined_revenue

    GROUP BY `Account Exe ID`

) r

ON ib.`Account Exe ID` = r.`Account Exe ID`

WHERE ib.Branch = 'Ahmedabad';

CREATE VIEW final_kpi_ahmedabad AS

SELECT 
    ib.Branch,
    ib.`Account Exe ID`,
    ib.`Employee Name`,
    ib.`New Budget`,
    ib.`Cross sell bugdet`,
    ib.`Renewal Budget`,

    COALESCE(r.New_Achieved,0) AS New_Achieved,
    COALESCE(r.Cross_Achieved,0) AS Cross_Achieved,
    COALESCE(r.Renewal_Achieved,0) AS Renewal_Achieved

FROM `individual budgets` ib

LEFT JOIN (

    SELECT 
        `Account Exe ID`,

        ROUND(SUM(CASE 
            WHEN income_class = 'New' 
            THEN Amount ELSE 0 END),2) AS New_Achieved,

        ROUND(SUM(CASE 
            WHEN income_class = 'Cross Sell' 
            THEN Amount ELSE 0 END),2) AS Cross_Achieved,

        ROUND(SUM(CASE 
            WHEN income_class = 'Renewal' 
            THEN Amount ELSE 0 END),2) AS Renewal_Achieved

    FROM (
        SELECT `Account Exe ID`, income_class, Amount FROM invoice
        UNION ALL
        SELECT `Account Exe ID`, income_class, Amount FROM fees
        UNION ALL
        SELECT `Account Exe ID`, income_class, Amount FROM brokerage
    ) AS combined_revenue

    GROUP BY `Account Exe ID`

) r

ON ib.`Account Exe ID` = r.`Account Exe ID`

WHERE ib.Branch = 'Ahmedabad';

SELECT * FROM final_kpi_ahmedabad;